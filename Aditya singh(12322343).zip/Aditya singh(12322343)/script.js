function calculateFactorial() {
  const input = document.getElementById("number").value.trim();
  const num = parseInt(input);
  if (isNaN(num) || num < 0) {
    document.getElementById("result").innerText = "Please enter a non-negative integer.";
    return;
  }

  let result = factorial(num);
  document.getElementById("result").innerText = `Factorial of ${num} is: ${result}`;
}

function factorial(n) {
  if (n === 0 || n === 1) return 1;
  return n * factorial(n - 1);
}
